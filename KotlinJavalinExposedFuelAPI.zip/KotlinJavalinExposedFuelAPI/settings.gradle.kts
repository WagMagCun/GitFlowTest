
rootProject.name = "KotlinJavalinExposedFuelAPI"

