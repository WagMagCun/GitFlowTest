package com.amiibo.search.useCase.exception

class AmiiboNotFoundException(message: String): Exception(message)