import com.amiibo.search.adapter.repository.ExposedAmiiboRepository
import com.amiibo.search.adapter.repository.exposed.config.DatabaseFactory
import com.amiibo.search.application.http.startHttpServer
import org.jetbrains.exposed.sql.Database
import org.joda.money.CurrencyUnit
import org.joda.money.Money


fun main(args: Array<String>) {

    val createHikariDataSourceWithRetry = DatabaseFactory.createHikariDataSourceWithRetry(
        System.getenv("jdbcUrl") ?: "jdbc:postgresql://localhost:5433/javalinexposedfuel?createDatabaseIfNotExist=true",
        "root", //System.getenv("username") ?: "root",
        "root", //System.getenv("pass") ?: "root",
        System.getenv("driverClassName") ?: "org.postgresql.Driver"
    )

    val connect = Database.connect(createHikariDataSourceWithRetry)
    connect.useNestedTransactions = true

    ExposedAmiiboRepository.createDatabase()

    startHttpServer()
}